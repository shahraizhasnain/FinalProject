/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// **********************  ALL REUSEABLE FUNCTIONS ******************* //


// ********  All Functions related to User Session ************ //


/**
 * 
 * @param {object} formData
 * @param {object} callback
 * @returns {string}
 */
function signupUser(formData, callback) {
    var requestUrl = baseUrl.apiServer.concat(api.user.signup);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: null,
        data: formData.data
    };

    var respData = {
        message: "",
        data: "null"
    };

//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} formData
 * @returns {string}
 */
function loginUser(formData, callback) {
    var requestUrl = baseUrl.apiServer.concat(api.user.login);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: null,
        data: formData.data
    };
    console.log(reqData.data);

    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "user login successfully") {
                // now saving user information,
                // client-id and token to cookies

                var xClientId = null;
                var sessionToken = null;
                var userName = null;
                var userFirstName = null;
                var userLastName = null;
                var userId = null;
                var pathDomain = null;
                var subscribedPatients = null;
                var userRole = null;

                xClientId = escape(resp.ajaxData.data.credentials[0].client_id);
                sessionToken = escape(resp.ajaxData.data.credentials[0].token);
                userName = escape(resp.ajaxData.data.user.profile.user_name);
                userFirstName = escape(resp.ajaxData.data.user.profile.first_name);
                userLastName = escape(resp.ajaxData.data.user.profile.last_name);
                userId = escape(resp.ajaxData.data.user.profile.users_id);
                userRole = escape(resp.ajaxData.data.user.profile.role);
                subscribedPatients = escape(resp.ajaxData.data.user.stats.subscribedPatients);
                pathDomain = "localhost";

                setBrowserCookie('x-client-id', xClientId, '1', pathDomain);
                setBrowserCookie('token', sessionToken, '1', pathDomain);
                setBrowserCookie('user-id', userId, '1', pathDomain);
                setBrowserCookie('user-name', userName, '1', pathDomain);
                setBrowserCookie('user-first-name', userFirstName, '1', pathDomain);
                setBrowserCookie('user-last-name', userLastName, '1', pathDomain);
                setBrowserCookie('user-role', userRole, '1', pathDomain);
                setBrowserCookie('total-patients-subscribe', subscribedPatients, '1', pathDomain);

                respData = {
                    message: resp.ajaxData.meta.message,
                    data: resp.ajaxData.data
                };
            } else if (resp.ajaxData.meta.message === "invalid username and password" || resp.ajaxData.meta.message === "username and password is required" || resp.ajaxData.meta.message === "user login failed") {
                respData = {
                    message: resp.ajaxData.meta.message,
                    data: resp.ajaxData.data
                };
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {function} callback
 * @returns {string}
 */
function logoutUser(callback) {
    var userId = getBrowserCookie('user-id');
    var sessionToken = getBrowserCookie('token');
    var requestUrl = baseUrl.apiServer.concat(api.user.logout);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            token: sessionToken,
            "user-id": userId
        },
        data: {
            users_id: userId
        }
    };

    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "logout Successfully") {
//              now deleting user data from cookie 
                deleteBrowserCookie('x-client-id');
                deleteBrowserCookie('token');
                deleteBrowserCookie('user-id');
                deleteBrowserCookie('user-name');
                deleteBrowserCookie('user-first-name');
                deleteBrowserCookie('user-last-name');
                deleteBrowserCookie('user-role');
                deleteBrowserCookie('total-patients-subscribe');
                respData = {
                    message: resp.ajaxData.meta.message
                };
            } else {
                respData = {
                    message: resp.ajaxData.meta.message
                };
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}


// ********  All Functions related to User ************ //
/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function userProfile(formData,callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.user.profile.all);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: {
            users_id: userId
        }
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function getUserProfile(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.user.profile.get);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: {
            users_id: userId
        }
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} formData
 * @param {object} callback
 * @returns {string}
 */
function isUserNameAvailable(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.user.check);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * Update user profile
 * @param {object} formData
 * @param {object} callback
 */
function updateUserProfile(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.user.profile.update);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} formData
 * @param {object} callback
 * @returns {string}
 */
function uploadProfilePicture(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.uploadFiles.profile) + '?imageof=' + formData.data.imageOf;
    console.log(requestUrl, "here");
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
   // console.log(reqData);
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

// ********  All Random Functions Related Web Page ************ //

//Functions for getting list of countries
//states and cities

/**
 * @param {object} formData
 * @param {object} callback
 * @returns {object} respData
 */
function getCountries(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.country.get);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} formData
 * @param {function} callback
 * @returns {object}
 */
function getStates(formData, callback) {

    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.state.get);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * @param {object} formData
 * @param {object} callback
 * @returns {object} respData
 */
function getCities(formData, callback) {

    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.city.getall);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}
/**
 * @param {object} formData
 * @param {object} callback
 * @returns {object} respData
 * location
 */
function getLocation(formData, callback) {

    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.location.get);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}
/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function getPatientProfilePage(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.profile);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: {
            patients_id: formData.patients_id
        }
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function viewPatientPage(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.view);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: {
            users_id: userId
        }
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "total patients") {
                respData = {
                    message: "total patients",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function searchPatientPage(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.profile);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId

        },
        data: "null"
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "") {
                respData = {
                    message: "",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function patientListPage(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.list);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: "null"
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "") {
                respData = {
                    message: "",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function addPatientPage(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.add);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    console.log(reqData);
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function updatePatientsProfile(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.update);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
    //  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}


/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function initialAssessmentPage(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.patient.assessment.initial);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken
        },
        data: "null"
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "") {
                respData = {
                    message: "",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function dashboardPage(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.dashboard.get);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken
        },
        data: "null"
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "") {
                respData = {
                    message: "",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * 
 * @param {object} callback
 * @returns {object} respData
 */
function welocmePage(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.welcome.get);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken
        },
        data: "null"
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "") {
                respData = {
                    message: "",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

function callPatientProfile(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(page.patient.profile);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.patient_id
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "") {
                respData = {
                    message: "",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * Returns userId
 * @returns {integer} userId
 */
function getUserIdFromCookie(callback) {
    var userId = getBrowserCookie('user-id') || "null";
    return callback(userId);
}

/**
 * 
 * Add patients into Cart
 */
function addToCart(formData, callback) {
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.user.cart);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data // patientsId:1
    };

    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {


            var subscribedPatients = escape(resp.ajaxData.data.user.stats.subscribedPatients);

            var pathDomain = "localhost";

            setBrowserCookie('total-patients-subscribe', subscribedPatients, '1', pathDomain);

            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

/**
 * send ud message code
 * @param {object} formData
 * @param {object} callback
 * @returns {string}
 */
function sendUsMessage(formData, callback) {
    var requestUrl = baseUrl.apiServer.concat(api.email.send);
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };

    var respData = {
        message: "",
        data: "null"
    };

//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {

            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}


// ********  All Functions related to Admin Panel ************ //

/**
 * get total users and there detail
 * @param {object} formData
 * @param {object} callback
 * @returns {object} respData
 */
function getTotalUsers(formData,callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.admin.totalUsers);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: {
            users_id: userId
        }
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}
function addProperty(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.property.add);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

function addPropertyImg(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.property.addImg);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

function searchProperty(formData, callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.property.search);
    var reqData = {
        url: requestUrl,
        type: formData.type,
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: formData.data
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            respData = {
                message: resp.ajaxData.meta.message,
                data: resp.ajaxData.data
            };
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}

function viewProperty(callback) {
    var clientId = getBrowserCookie('x-client-id');
    var sessionToken = getBrowserCookie('token');
    var userId = getBrowserCookie('user-id');
    var requestUrl = baseUrl.apiServer.concat(api.property.view);
    var reqData = {
        url: requestUrl,
        type: "POST",
        headers: {
            "x-client-id": clientId,
            "token": sessionToken,
            "user-id": userId
        },
        data: {
            users_id: userId
        }
    };
    var respData = {
        message: "",
        data: "null"
    };
//  calling callAjax function 
    callAjax(reqData, function (resp) {
        if (resp.ajaxMessage === "success") {
            if (resp.ajaxData.meta.message === "property") {
                respData = {
                    message: "property",
                    data: resp.ajaxData.data
                };
            } else {
                respData.message = "user is not logged in";
            }
        }
        else {
            respData.message = "errors";
        }
        return callback(respData);
    });
}
