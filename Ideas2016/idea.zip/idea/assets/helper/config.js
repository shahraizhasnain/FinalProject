/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *  Setting configuration settings
 */

//setting Base Urls
var baseUrl = {
    apiServer: 'http://localhost/gharbar/gharbar_apis/',
    websiteServer: 'http://localhost/gharbar/gharbar/'
// apiServer: 'http://www.gharbaar.com.pk/gharbar_apis/',
// websiteServer: 'http://www.gharbaar.com.pk/'
};
//setting API Urls
var api = {
    user: {
        signup: 'Session/signup',
        login: 'Session/login',
        logout: 'Session/logout',
        check: 'User/check',
        cart: 'User/cart',
        profile: {
            get: 'User/profile',
            update: 'User/update',
            delete: 'User/deelte'
        }
    },
//    patient: {
//        get: 'null',
//        add: 'Patient/add',
//        update: 'Patient/update',
//        delete: 'Patient/delete',
//        profile: 'Patient/profile',
//        view: 'Patient/view',
//        search: 'Patient/search',
//        list: 'Patient/list',
//        assessment: {
//            initial: 'Assessment/initial'
//        }
//    },
    property: {
        get: 'null',
        add: 'Property/add',
        addImg:'Property/addImg',
        update: 'Patient/update',
        delete: 'Patient/delete',
        profile: 'Patient/profile',
        view: 'Property/view',
        search:'Property/search',
        assessment: {
            initial: 'Assessment/initial'
        }
    },
    country: {
        get: 'Country/getCountries',
        add: '',
        update: '',
        delete: ''
    },
    state: {
        get: 'Country/getStates',
        add: '',
        update: '',
        delete: ''
    },
    city: {
        getall:'Country/getAllCities',
        get: 'Country/getCities',
        add: '',
        update: '',
        delete: ''
    },
    location: {
        get: 'Country/getLocation'
    },
    dashboard: {
        get: 'Dashboard/'
    },
    welcome: {
        get: 'Welcome/'
    },
    home: {
        get: 'Home/'
    },
    uploadFiles: {
        profile: 'Upload_Files/image'
    },
    email: {
        send: 'Send_Email/send'
    },
    admin: {
        totalUsers: 'Admin/totalUsers',
        assessmentForm: {
            save: 'Admin/saveAssessmentForm',
            update: ''
        }
    }

};
//setting Website Urls
var page = {
    home: {
        get: 'Home/'
    },
    dashboard: {
        get: 'Dashboard/'
    },
    welcome: {
        get: 'Welcome/'
    },
    user: {
        add: 'null',
        update: 'null',
        delete: 'null',
        profile: 'User/profile',
        signup: 'User/signup',
        login: 'User/login'
    },
    patient: {
        get: 'null',
        add: 'Patient/add',
        update: 'Patient/update',
        delete: 'Patient/delete',
        profile: 'Patient/profile',
        view: 'Patient/view',
        search: 'Patient/search',
        list: 'Patient/grid',
        assessment: {
            initial: 'Assessment/initial'
        }
    },
    property:{
        add:'Property/add',
        addImage:'Property/addImage',
        search:'Property/search'
    },
    terms: {
        termsCondition: 'Terms/',
        termsMembers: 'Terms/membersTerms/'
    },
    faqs: {
        faq: 'Faqs/'
    },
    privacy: {
        policy: 'Privacy/'
    },
    prices: {
        Prices: 'Prices/'
    },
    checkout: {
        Checkout: 'Checkout/'
    },
    admin: {
        dashboard: 'Admin/dashboard',
        assessmentForm: 'Admin/assessmentForm/'
    }
};