<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/style.css">
    </head>
    <body style="background-image:url(<?= base_url(); ?>assets/images/BG.png); background-size:cover;">
        <div class="container bg">
            <div class="row" style="margin-top:50px;">
                <div class="row" style="max-width:100%;padding-top:120px;">
                    <div class="col-md-offset-4 col-md-4" style="background-color: rgba(255,255,255,0.5);">
                        <div class="login-panel">
                            <div class="login-head">
                                <div class="row">
                                    <div class="col-md-12" style="text-align:center;">
                                        <img src="<?= base_url(); ?>assets/images/getconn_bigg_03.png" style="width: 40%;padding:10px;">
                                    </div>
                                </div>
                                <div class="row p-20">
                                    <div class="form-group">
                                        <input type="text" class="form-control h-50" placeholder="Login">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control h-50" placeholder="Password">
                                    </div>
                                    <div class="row mb-20">
                                        <div class="col-md-4"></div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <button class="btn btn-lg btn-primary w100"> Login</button>
                                            </div>
                                        </div>
                                        <div class="col-md-4"></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>